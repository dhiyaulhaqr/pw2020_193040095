<?php 
    $a = 5;

    print ("Aku adalah angka $a");
    print ("</br>");
    print  ("Jika aku ditambah 20, jumlahku sekarang " . $a +=  20);
    print("</br>");
    print ("Jika aku dikali 4, jumlahku sekarang " . $a*= 4);
    print ("</br>");
    print ("Jika aku dikurangi 10, jumlahku sekarang ". $a-= 10);
    print ("</br>");
    print ("Jika aku dibagi 5, maka sisaku sekarang ". $a%= 5);
?>