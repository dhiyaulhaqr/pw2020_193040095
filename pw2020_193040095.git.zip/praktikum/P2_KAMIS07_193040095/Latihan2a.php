<?php
    for ($i = 1; $i <=3; $i++) {
        for ($b = 1; $b <=3; $b++){
            echo "ini pengulangan ke ($i, $b)<br>";
        }
    }






?>